import { useState } from "react";

type Service = {
  number: string;
  title: string;
  text: string;
  items: string[];
};

const services: Service[] = [
  {
    number: "01",
    title: "مشاوره مالی",
    text: "تبدیل اطلاعات مالی پراکنده به اطلاعاتی که مدیر بتواند بر اساس آن تصمیم بگیرد.",
    items: ["گزارش‌های مدیریتی", "بودجه و پیش‌بینی", "تحلیل سودآوری", "داشبورد مدیریتی"],
  },
  {
    number: "02",
    title: "مشاوره عملیاتی",
    text: "پیدا کردن گلوگاه‌های عملیاتی و تبدیل مسئله‌های روزمره به برنامه قابل اجرا.",
    items: ["بهبود فرآیند", "کنترل هزینه", "مدیریت نقدینگی", "KPI و شاخص‌های عملکرد"],
  },
  {
    number: "03",
    title: "تحلیل و تصمیم‌گیری",
    text: "قبل از تصمیم، سؤال درست را مشخص می‌کنیم؛ سپس داده مناسب برای آزمون آن سؤال را پیدا می‌کنیم.",
    items: ["تحلیل داده", "Cost Mapping", "ABC Costing", "تحلیل انحرافات"],
  },
];

const problems = [
  "فروش دارید اما سود واقعی را نمی‌دانید.",
  "مطالبات وصول نمی‌شود و نقدینگی تحت فشار است.",
  "هزینه‌ها بالا رفته اما علت مشخص نیست.",
  "گزارش مالی دارید، ولی برای تصمیم مدیریتی کافی نیست.",
  "فرآیندها به افراد وابسته شده‌اند.",
  "مدیر برای تصمیم‌گیری به اطلاعات سریع و قابل اتکا دسترسی ندارد.",
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <div className="site">
      <header className="nav">
        <div className="container nav-inner">
          <button className="brand" onClick={() => scrollTo("home")} aria-label="خانه">
            <span className="brand-mark">JD</span>
            <span>
              <strong>جواد دومانلو</strong>
              <small>مشاور مالی و عملیاتی</small>
            </span>
          </button>

          <button
            className="menu-toggle"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="منو"
          >
            ☰
          </button>

          <nav className={menuOpen ? "nav-links open" : "nav-links"}>
            <button onClick={() => scrollTo("services")}>خدمات</button>
            <button onClick={() => scrollTo("method")}>رویکرد من</button>
            <button onClick={() => scrollTo("problems")}>مسائل کسب‌وکار</button>
            <button onClick={() => scrollTo("about")}>درباره من</button>
            <button className="nav-cta" onClick={() => scrollTo("contact")}>شروع گفتگو</button>
          </nav>
        </div>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="hero-glow glow-one" />
          <div className="hero-glow glow-two" />

          <div className="container hero-grid">
            <div className="hero-copy">
              <div className="eyebrow">
                <span />
                Financial & Operational Consulting
              </div>

              <h1>
                عددها را
                <br />
                به <em>تصمیم</em> تبدیل کنیم.
              </h1>

              <p className="hero-lead">
                من جواد دومانلو هستم؛ مشاور مالی و عملیاتی.
                کمک می‌کنم مدیران، پشت اعداد و گزارش‌ها، مسئله واقعی کسب‌وکارشان را ببینند
                و برای آن تصمیم قابل اجرا بگیرند.
              </p>

              <div className="hero-actions">
                <button className="primary-btn" onClick={() => scrollTo("contact")}>
                  درباره مسئله کسب‌وکارم صحبت کنیم <span>←</span>
                </button>
                <button className="text-btn" onClick={() => scrollTo("services")}>
                  خدمات مشاوره <span>↓</span>
                </button>
              </div>

              <div className="hero-trust">
                <div><b>مالی</b><span>Financial</span></div>
                <div><b>عملیاتی</b><span>Operational</span></div>
                <div><b>تصمیم</b><span>Decision</span></div>
              </div>
            </div>

            <div className="hero-card-wrap">
              <div className="hero-card">
                <div className="card-top">
                  <span>MANAGEMENT VIEW</span>
                  <span className="live-dot">● LIVE</span>
                </div>

                <div className="metric-main">
                  <span>دید مدیریتی</span>
                  <strong>360°</strong>
                  <small>مالی + عملیات + تصمیم</small>
                </div>

                <div className="mini-chart">
                  <div className="chart-line">
                    <i style={{ height: "34%" }} />
                    <i style={{ height: "45%" }} />
                    <i style={{ height: "41%" }} />
                    <i style={{ height: "59%" }} />
                    <i style={{ height: "54%" }} />
                    <i style={{ height: "72%" }} />
                    <i style={{ height: "88%" }} />
                  </div>
                </div>

                <div className="card-footer">
                  <span>داده</span>
                  <span>→</span>
                  <span>تحلیل</span>
                  <span>→</span>
                  <span>تصمیم</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="problems" className="section problems">
          <div className="container">
            <div className="section-heading split">
              <div>
                <span className="section-number">01 / مسئله</span>
                <h2>اگر این سؤال‌ها<br /><span>برای شما آشناست...</span></h2>
              </div>
              <p>
                مسئله همیشه کمبود گزارش نیست؛ گاهی مشکل این است که گزارش درست،
                برای سؤال درست استفاده نمی‌شود.
              </p>
            </div>

            <div className="problem-grid">
              {problems.map((problem, index) => (
                <div className="problem-card" key={problem}>
                  <span>0{index + 1}</span>
                  <p>{problem}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="services" className="section services">
          <div className="container">
            <div className="section-heading">
              <span className="section-number">02 / خدمات</span>
              <h2>مشاوره برای <span>دیدن، تحلیل کردن و اقدام کردن.</span></h2>
            </div>

            <div className="service-list">
              {services.map((service) => (
                <article className="service-card" key={service.number}>
                  <div className="service-number">{service.number}</div>
                  <div className="service-content">
                    <h3>{service.title}</h3>
                    <p>{service.text}</p>
                    <div className="service-items">
                      {service.items.map((item) => <span key={item}>{item}</span>)}
                    </div>
                  </div>
                  <div className="service-arrow">↗</div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="method" className="section method">
          <div className="container method-grid">
            <div className="method-title">
              <span className="section-number">03 / رویکرد</span>
              <h2>اول سؤال.<br /><span>بعد داده.</span></h2>
            </div>

            <div className="method-content">
              <p className="big-copy">
                قبل از اینکه دنبال گزارش بگردیم، مشخص می‌کنیم مدیر دقیقاً چه تصمیمی
                باید بگیرد و چه فرضیه‌ای باید آزمون شود.
              </p>

              <div className="steps">
                <div><b>01</b><span>تعریف مسئله</span><small>What is wrong?</small></div>
                <div><b>02</b><span>انتخاب داده</span><small>What do we need?</small></div>
                <div><b>03</b><span>تحلیل</span><small>What does it say?</small></div>
                <div><b>04</b><span>اقدام</span><small>What should we do?</small></div>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="section about">
          <div className="container about-grid">
            <div className="about-visual">
              <div className="portrait-placeholder">
                <span>JD</span>
                <small>JAVAD DOMANLOU</small>
              </div>
            </div>

            <div className="about-copy">
              <span className="section-number">04 / درباره من</span>
              <h2>حسابداری فقط<br /><span>شروع ماجراست.</span></h2>
              <p>
                مسیر حرفه‌ای من از حوزه مالی و حسابداری شروع شده و به سمت مشاوره مالی
                و عملیاتی و حل مسئله مدیریتی حرکت کرده است.
              </p>
              <p>
                تمرکز من روی این است که اطلاعات مالی را از یک خروجی حسابداری،
                به ابزاری برای کنترل، تحلیل و تصمیم‌گیری تبدیل کنم.
              </p>

              <div className="signature">Javad Domanlou</div>
            </div>
          </div>
        </section>

        <section id="contact" className="contact">
          <div className="container contact-inner">
            <div>
              <span className="section-number">05 / شروع گفتگو</span>
              <h2>مسئله کسب‌وکارتان<br /><span>چیست؟</span></h2>
              <p>اگر فکر می‌کنید یک مسئله مالی یا عملیاتی مانع رشد کسب‌وکارتان شده، از همین‌جا شروع کنیم.</p>
            </div>

            <button className="contact-btn" onClick={() => window.location.href = "mailto:contact@example.com"}>
              <span>تماس برای مشاوره</span>
              <b>↗</b>
            </button>
          </div>
        </section>
      </main>

      <footer>
        <div className="container footer-inner">
          <div>
            <strong>جواد دومانلو</strong>
            <span>مشاور مالی و عملیاتی</span>
          </div>
          <span>© 2026 — Financial & Operational Consulting</span>
        </div>
      </footer>
    </div>
  );
}

export default App;